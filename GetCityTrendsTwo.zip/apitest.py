import requests
import boto3
import ast

url = "https://api.twitter.com/1.1/trends/closest.json?lat=38.9072&long=-77.0369"
payload = {}
headers = {
  'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAG2lIQEAAAAAE5TD3e7tlEOpeuOgxOhtWPogdFg%3D5JqpMH4TfegrUMsVzYQdXdKzY5g5B0oFimOG0M03FCt7jFEPUM',
  'Cookie': 'personalization_id="v1_qUGrkUWYCpcJUzaf5oGL7g=="; guest_id=v1%3A160217578401863623'
}
response = requests.request("GET", url, headers=headers)

output = response.json()
string = str(output)[1:-1]
data_dict = ast.literal_eval(string)
woeid = str(data_dict['woeid'])
city = str(data_dict['name'])
country = str(data_dict['country'])
yahoourl = str(data_dict['url'])

print(yahoourl)