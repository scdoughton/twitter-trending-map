from pytz import timezone
import requests
import json
import datetime


Apiurl = "https://api.twitter.com/1.1/trends/place.json?id=1"
payload = {}
headers = {
    'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAG2lIQEAAAAAE5TD3e7tlEOpeuOgxOhtWPogdFg%3D5JqpMH4TfegrUMsVzYQdXdKzY5g5B0oFimOG0M03FCt7jFEPUM',
    'Cookie': 'personalization_id="v1_qUGrkUWYCpcJUzaf5oGL7g=="; guest_id=v1%3A160217578401863623'
}

response = requests.request("GET", Apiurl, headers=headers)
output = response.text.encode('utf8')
data_dict = json.loads(output)
tz = timezone('US/Eastern')
crntTimeStamp = datetime.datetime.now(tz).strftime('%m-%d-%Y %I:%M %p')



print(data_dict)

for item in data_dict:
    data_dict = item['trends']
    for trend in data_dict:
        name = str(trend['name'])
        url = str(trend['url'])
        tweet_volume = str(trend['tweet_volume'])
        print(name, url, tweet_volume, crntTimeStamp)
